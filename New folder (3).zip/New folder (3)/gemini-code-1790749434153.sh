git remote add origin https://github.com/YOUR_USERNAME/servicenow-incident-skill-wallet.git
git push -u origin main