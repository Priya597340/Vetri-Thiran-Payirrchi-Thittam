git add .
git commit -m "feat: implement Client Scripts and UI Policies for Incident table"